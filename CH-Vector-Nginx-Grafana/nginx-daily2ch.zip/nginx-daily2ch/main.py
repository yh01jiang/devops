#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Nginx日志归档分析脚本
功能：
1. 按天统计高峰时段（每0.5h周期，取PV最大的周期）
2. 基于高峰时段统计QPS、响应时间、流量等指标
3. 统计全天UV、PV、状态码分布、成功率
4. 支持当天、最近X天、全部数据的统计
"""
import math
import argparse
import sys
import json
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from clickhouse_driver import Client
import numpy as np
from db_init import create_archive_table, insert_daily_data, delete_daily_data

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass  # 如果没有安装python-dotenv，继续使用默认值

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', handlers=[logging.StreamHandler(sys.stdout)])
logger = logging.getLogger(__name__)


class NginxLogAnalyzer:
    def __init__(self, host, port, database, table, user, password):
        """
        初始化ClickHouse连接
        """
        self.client = Client(host=host, port=port, database=database, user=user, password=password)
        self.table = table
        # 保存数据库连接信息，用于写入归档数据
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        # 默认域名为'all'，表示所有数据
        self.default_domain = ' ALL'
        # 从环境变量读取配置
        self.peak_period_minutes = int(os.getenv('PEAK_PERIOD_MINUTES', '30'))
        self.qps_calculation_seconds = int(os.getenv('QPS_CALCULATION_SECONDS', '10'))
        self.traffic_calculation_seconds = int(os.getenv('TRAFFIC_CALCULATION_SECONDS', '10'))
        self.min_domain_requests = int(os.getenv('MIN_DOMAIN_REQUESTS', '20'))
        self.slow_path_min_requests = int(os.getenv('SLOW_PATH_MIN_REQUESTS', '1000'))
        # 初始化归档表
        self.archive_table = create_archive_table(host, port, database, table, user, password)

    def get_date_range(self, mode: str, days: int = 0) -> Tuple[str, str]:
        """
        根据模式获取日期范围
        mode: 'today', 'recent', 'all'
        days: 最近天数（仅在recent模式下使用）
        """
        today = datetime.now().date()

        if mode == 'today':
            start_date = today.strftime('%Y-%m-%d')
            end_date = (today + timedelta(days=1)).strftime('%Y-%m-%d')
        elif mode == 'recent':
            start_date = (today - timedelta(days=days)).strftime('%Y-%m-%d')
            end_date = today.strftime('%Y-%m-%d')
        else:  # all
            # 获取表中最早的日期
            query = f"SELECT min(toDate(timestamp)) as min_date FROM {self.table}"
            result = self.client.execute(query)
            if result and result[0][0]:
                start_date = result[0][0].strftime('%Y-%m-%d')
            else:
                start_date = '2025-01-01'  # 默认开始日期
            end_date = today.strftime('%Y-%m-%d')

        return start_date, end_date

    def find_peak_hours(self, date: str, domain: str = None) -> Tuple[str, str, int]:
        """
        找出指定日期和域名的高峰时段（每0.5小时周期，取PV最大的周期）
        返回：(开始时间, 结束时间, PV数量)
        """
        domain_condition = ""
        if domain and domain != self.default_domain:
            domain_condition = f"AND domain = '{domain}'"

        query = f"""
        SELECT 
            toStartOfInterval(timestamp, INTERVAL {self.peak_period_minutes} MINUTE) as period_start,
            count() as pv
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}' {domain_condition}
        GROUP BY period_start
        ORDER BY pv DESC
        LIMIT 1
        """

        result = self.client.execute(query)
        if not result:
            return "00:00:00", f"00:30:00", 0

        period_start = result[0][0]
        pv = result[0][1]
        period_end = period_start + timedelta(minutes=self.peak_period_minutes)

        return (period_start.strftime('%H:%M'), period_end.strftime('%H:%M'), pv)

    def calculate_peak_metrics(self, date: str, peak_start: str, peak_end: str, domain: str = None) -> Dict:
        """
        计算高峰时段的各项指标
        """
        # 构建完整的时间戳范围
        start_datetime = f"{date} {peak_start}:00"
        end_datetime = f"{date} {peak_end}:00"

        # 添加域名条件
        domain_condition = ""
        if domain and domain != self.default_domain:
            domain_condition = f"AND domain = '{domain}'"

        # QPS计算（每{self.qps_calculation_seconds}秒一个周期）
        qps_query = f"""
        SELECT 
            toStartOfInterval(timestamp, INTERVAL {self.qps_calculation_seconds} SECOND) as period,
            count() / {self.qps_calculation_seconds}.0 as qps
        FROM {self.table}
        WHERE timestamp >= toDateTime('{start_datetime}', 'Asia/Shanghai')
            AND timestamp < toDateTime('{end_datetime}', 'Asia/Shanghai')
            {domain_condition}
        GROUP BY period
        ORDER BY qps DESC
        """

        qps_results = self.client.execute(qps_query)
        qps_values = [row[1] for row in qps_results] if qps_results else [0]

        max_qps = max(qps_values) if qps_values else 0
        p99_qps = np.percentile(qps_values, 99) if qps_values else 0

        # 响应时间统计（转换为毫秒）
        response_time_query = f"""
        SELECT 
            avg(responsetime) * 1000 as avg_response_time,
            quantile(0.99)(responsetime) * 1000 as p99_response_time,
            quantile(0.90)(responsetime) * 1000 as p90_response_time
        FROM {self.table}
        WHERE timestamp >= toDateTime('{start_datetime}', 'Asia/Shanghai')
            AND timestamp < toDateTime('{end_datetime}', 'Asia/Shanghai')
            {domain_condition}
        """
        response_result = self.client.execute(response_time_query)
        if response_result and response_result[0]:
            avg_response_time = response_result[0][0] or 0
            p99_response_time = response_result[0][1] or 0
            p90_response_time = response_result[0][2] or 0
        else:
            avg_response_time = p99_response_time = p90_response_time = 0

        # 响应时间分布统计
        response_distribution_query = f"""
        SELECT 
            countIf(responsetime < 0.1) as under_100ms,
            countIf(responsetime >= 0.1 AND responsetime < 0.5) as ms_100_500,
            countIf(responsetime >= 0.5 AND responsetime < 1.0) as ms_500_1s,
            countIf(responsetime >= 1.0 AND responsetime < 2.0) as s_1_2,
            countIf(responsetime >= 2.0) as over_2s,
            count() as total_requests
        FROM {self.table}
        WHERE timestamp >= toDateTime('{start_datetime}', 'Asia/Shanghai')
            AND timestamp < toDateTime('{end_datetime}', 'Asia/Shanghai')
            {domain_condition}
        """

        distribution_result = self.client.execute(response_distribution_query)
        if distribution_result and distribution_result[0]:
            under_100ms, ms_100_500, ms_500_1s, s_1_2, over_2s, total_requests = distribution_result[0]
        else:
            under_100ms = ms_100_500 = ms_500_1s = s_1_2 = over_2s = total_requests = 0

        # 流量统计（每{self.traffic_calculation_seconds}秒周期）
        traffic_query = f"""
        SELECT 
            toStartOfInterval(timestamp, INTERVAL {self.traffic_calculation_seconds} SECOND) as period,
            sum(request_length) * 8 / {self.traffic_calculation_seconds}.0 as request_bps,
            sum(response_length) * 8 / {self.traffic_calculation_seconds}.0 as response_bps
        FROM {self.table}
        WHERE timestamp >= toDateTime('{start_datetime}', 'Asia/Shanghai')
            AND timestamp < toDateTime('{end_datetime}', 'Asia/Shanghai')
            {domain_condition}
        GROUP BY period
        """

        traffic_results = self.client.execute(traffic_query)
        if traffic_results:
            max_request_bps = max(row[1] for row in traffic_results)
            max_response_bps = max(row[2] for row in traffic_results)
        else:
            max_request_bps = max_response_bps = 0

        # 处理可能的NaN值，避免转换为整数时出错
        def safe_round(value):
            if isinstance(value, float) and math.isnan(value):
                return 0
            return round(value)

        return {
            'max_qps': safe_round(max_qps),
            'p99_qps': safe_round(p99_qps),
            'avg_response_time': safe_round(avg_response_time),
            'p99_response_time': safe_round(p99_response_time),
            'p90_response_time': safe_round(p90_response_time),
            'max_request_bps': safe_round(max_request_bps),
            'max_response_bps': safe_round(max_response_bps),
            'under_100ms': under_100ms,
            'ms_100_500': ms_100_500,
            'ms_500_1s': ms_500_1s,
            's_1_2': s_1_2,
            'over_2s': over_2s,
        }

    def calculate_daily_metrics(self, date: str, domain: str = None) -> Dict:
        """
        计算全天指标
        """
        # 添加域名条件
        domain_condition = ""
        if domain and domain != self.default_domain:
            domain_condition = f"AND domain = '{domain}'"
        # UV, PV统计
        uv_pv_query = f"""
        SELECT 
            uniq(client_ip) as uv,
            count() as pv
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            {domain_condition}
        """

        uv_pv_result = self.client.execute(uv_pv_query)
        if uv_pv_result and uv_pv_result[0]:
            uv, pv = uv_pv_result[0]
        else:
            uv = pv = 0

        # 状态码统计
        status_query = f"""
        SELECT 
            countIf(status >= 100 AND status < 200) as status_1xx,
            countIf(status >= 200 AND status < 300) as status_2xx,
            countIf(status >= 300 AND status < 400) as status_3xx,
            countIf(status >= 400 AND status < 500) as status_4xx,
            countIf(status >= 500 AND status < 600) as status_5xx,
            countIf(status < 400) / count() as success_rate
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            {domain_condition}
        """

        status_result = self.client.execute(status_query)
        if status_result and status_result[0]:
            status_1xx, status_2xx, status_3xx, status_4xx, status_5xx, success_rate = status_result[0]
        else:
            status_1xx = status_2xx = status_3xx = status_4xx = status_5xx = 0
            success_rate = 0

        # 操作系统统计
        os_query = f"""
        SELECT 
            countIf(lowerUTF8(client_os_family) = 'windows') as windows_count,
            countIf(lowerUTF8(client_os_family) = 'android') as android_count,
            countIf(lowerUTF8(client_os_family) = 'ios') as ios_count,
            countIf(lowerUTF8(client_os_family) like 'mac%') as mac_count,
            count() as total_count
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            {domain_condition}
        """

        os_result = self.client.execute(os_query)
        if os_result and os_result[0]:
            windows_count, android_count, ios_count, mac_count, total_count = os_result[0]
            # 计算其他操作系统数量
            other_count = total_count - windows_count - android_count - ios_count - mac_count
        else:
            windows_count = android_count = ios_count = mac_count = total_count = other_count = 0

        # 用户IP请求数top10
        ip_top10_query = f"""
        SELECT 
            count() as request_count,
            client_ip
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            {domain_condition}
        GROUP BY client_ip
        ORDER BY count() DESC
        LIMIT 10
        """

        ip_top10_result = self.client.execute(ip_top10_query)
        ip_top10_fields = {}
        for i in range(10):
            if i < len(ip_top10_result):
                count, ip = ip_top10_result[i]
                ip_top10_fields[f'ip_top{i+1}'] = f"{count}:{ip}"
            else:
                ip_top10_fields[f'ip_top{i+1}'] = "0:"

        # path请求数top10
        path_top10_query = f"""
        SELECT 
            count() as request_count,
            path
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            {domain_condition}
        GROUP BY path
        ORDER BY count() DESC
        LIMIT 10
        """

        path_top10_result = self.client.execute(path_top10_query)
        path_top10_fields = {}
        for i in range(10):
            if i < len(path_top10_result):
                count, path = path_top10_result[i]
                path_top10_fields[f'path_top{i+1}'] = f"{count}:{path}"
            else:
                path_top10_fields[f'path_top{i+1}'] = "0:"

        # 大于1000pv的请求,响应时间top10
        slow_path_top10_query = f"""
        SELECT 
            avg(responsetime) * 1000 as avg_response_time,
            path,
            count() as request_count
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            {domain_condition}
        GROUP BY path
        HAVING count() > {self.slow_path_min_requests}
        ORDER BY avg(responsetime) DESC
        LIMIT 10
        """

        slow_path_top10_result = self.client.execute(slow_path_top10_query)
        slow_path_top10_fields = {}
        for i in range(10):
            if i < len(slow_path_top10_result):
                avg_rt, path, count = slow_path_top10_result[i]
                slow_path_top10_fields[f'slow_path_top{i+1}'] = f"{round(avg_rt)}ms:{path}:{count}"
            else:
                slow_path_top10_fields[f'slow_path_top{i+1}'] = "0::"

        # 用户IP请求path次数top10
        ip_path_top10_query = f"""
        SELECT 
            COUNT() as request_count,
            path,
            client_ip
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            {domain_condition}
        GROUP BY client_ip, path
        ORDER BY COUNT() DESC
        LIMIT 10
        """

        ip_path_top10_result = self.client.execute(ip_path_top10_query)
        ip_path_top10_fields = {}
        for i in range(10):
            if i < len(ip_path_top10_result):
                count, path, ip = ip_path_top10_result[i]
                ip_path_top10_fields[f'ip_path_top{i+1}'] = f"{count}:{path}:{ip}"
            else:
                ip_path_top10_fields[f'ip_path_top{i+1}'] = "0::"

        # 4xx错误path top10
        error_4xx_top10_query = f"""
        SELECT 
            COUNT() as request_count,
            path
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            AND status >= 400 AND status < 500
            {domain_condition}
        GROUP BY path
        ORDER BY COUNT() DESC
        LIMIT 10
        """

        error_4xx_top10_result = self.client.execute(error_4xx_top10_query)
        error_4xx_top10_fields = {}
        for i in range(10):
            if i < len(error_4xx_top10_result):
                count, path = error_4xx_top10_result[i]
                error_4xx_top10_fields[f'error_4xx_top{i+1}'] = f"{count}:{path}"
            else:
                error_4xx_top10_fields[f'error_4xx_top{i+1}'] = "0:"

        # 5xx错误path top10
        error_5xx_top10_query = f"""
        SELECT 
            COUNT() as request_count,
            path
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
            AND status >= 500 AND status < 600
            {domain_condition}
        GROUP BY path
        ORDER BY COUNT() DESC
        LIMIT 10
        """

        error_5xx_top10_result = self.client.execute(error_5xx_top10_query)
        error_5xx_top10_fields = {}
        for i in range(10):
            if i < len(error_5xx_top10_result):
                count, path = error_5xx_top10_result[i]
                error_5xx_top10_fields[f'error_5xx_top{i+1}'] = f"{count}:{path}"
            else:
                error_5xx_top10_fields[f'error_5xx_top{i+1}'] = "0:"

        # 合并所有结果
        result = {
            'uv': uv,
            'pv': pv,
            'status_1xx': status_1xx,
            'status_2xx': status_2xx,
            'status_3xx': status_3xx,
            'status_4xx': status_4xx,
            'status_5xx': status_5xx,
            'success_rate': round(success_rate * 100, 2),  # 转换为百分比
            'windows_count': windows_count,
            'android_count': android_count,
            'ios_count': ios_count,
            'mac_count': mac_count,
            'other_count': other_count,
        }

        # 添加TOP10字段
        result.update(ip_top10_fields)
        result.update(path_top10_fields)
        result.update(slow_path_top10_fields)
        result.update(ip_path_top10_fields)
        result.update(error_4xx_top10_fields)
        result.update(error_5xx_top10_fields)

        return result

    def get_date_list(self, start_date: str, end_date: str) -> List[str]:
        """
        获取日期范围内的所有日期列表
        """
        query = f"""
        SELECT DISTINCT toDate(timestamp) as date
        FROM {self.table}
        WHERE toDate(timestamp) >= '{start_date}'
            AND toDate(timestamp) < '{end_date}'
        ORDER BY date
        """

        results = self.client.execute(query)
        return [row[0].strftime('%Y-%m-%d') for row in results]

    def get_domain_list(self, date: str) -> List[str]:
        """
        获取指定日期的所有域名列表（请求次数大于{self.min_domain_requests}次）
        """
        query = f"""
        SELECT domain
        FROM {self.table}
        WHERE toDate(timestamp) = '{date}'
        GROUP BY domain
        HAVING COUNT() > {self.min_domain_requests}
        """

        results = self.client.execute(query)
        domains = [row[0] for row in results if row[0]]

        # 始终包含'all'域名，表示所有数据
        if self.default_domain not in domains:
            domains.append(self.default_domain)

        return domains

    def analyze(self, mode: str, days: int = 0) -> List[Dict]:
        """
        主分析函数
        """
        start_date, end_date = self.get_date_range(mode, days)
        date_list = self.get_date_list(start_date, end_date)

        results = []

        for date in date_list:
            logger.info(f"🌊正在分析 {date} 的数据...")

            # 删除该日期的所有数据，防止重复入库
            try:
                delete_daily_data(self.host, self.port, self.database, self.archive_table, self.user, self.password, date)
            except Exception as e:
                logger.warning(f"删除日期 {date} 的历史数据失败: {e}")

            # 获取该日期的所有域名
            domain_list = self.get_domain_list(date)

            for domain in domain_list:
                logger.info(f"🌐分析域名: {domain}")

                # 第一步：找出高峰时段
                peak_start, peak_end, peak_pv = self.find_peak_hours(date, domain)
                peak_period = f"{peak_start}-{peak_end}"

                # 第二步：计算高峰时段指标
                peak_metrics = self.calculate_peak_metrics(date, peak_start, peak_end, domain)

                # 第三步：计算全天指标
                daily_metrics = self.calculate_daily_metrics(date, domain)

                # 合并结果
                result = {'日期': date, '域名': domain, '高峰时段': peak_period, **peak_metrics, **daily_metrics}

                results.append(result)

                # 立即写入数据库
                try:
                    db_data = self.convert_to_db_format(result)
                    insert_daily_data(self.host, self.port, self.database, self.archive_table, self.user, self.password, db_data)
                    logger.info(f"🎉数据已写入数据库: {date} - {domain}")
                except Exception as e:
                    logger.error(f"写入数据库失败 {date} - {domain}: {e}")

        return results

    def output_results(self, results: List[Dict]):
        """
        输出结果为JSON格式
        """
        if not results:
            logger.warning("没有找到数据")
            return

        # 输出JSON格式结果
        output = {"analysis_time": datetime.now().isoformat(), "total_records": len(results), "data": results}

        # print(json.dumps(output, ensure_ascii=False, indent=2))
        logger.info(f"分析完成，共处理 {len(results)} 条记录，数据已实时写入数据库")

    def convert_to_db_format(self, result: Dict) -> Dict:
        """
        将分析结果转换为数据库表格式
        """
        # 处理日期格式
        date_str = result['日期']
        if isinstance(date_str, str):
            date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
        else:
            date_obj = date_str

        # 构建数据库记录
        db_data = {
            '日期': date_obj,
            '域名': result['域名'],
            '高峰时段': result['高峰时段'],
            '最大QPS': result.get('max_qps', 0),
            'P99QPS': result.get('p99_qps', 0),
            '平均RT': result.get('avg_response_time', 0),
            'P99RT': result.get('p99_response_time', 0),
            'P90RT': result.get('p90_response_time', 0),
            '100ms以下': result.get('under_100ms', 0),
            '100-500ms': result.get('ms_100_500', 0),
            '500-1kms': result.get('ms_500_1s', 0),
            '1k-2kms': result.get('s_1_2', 0),
            '2kms以上': result.get('over_2s', 0),
            '最大请求量': result.get('max_request_bps', 0),
            '最大返回量': result.get('max_response_bps', 0),
            '总UV': result.get('uv', 0),
            '总PV': result.get('pv', 0),
            '1xx': result.get('status_1xx', 0),
            '2xx': result.get('status_2xx', 0),
            '3xx': result.get('status_3xx', 0),
            '4xx': result.get('status_4xx', 0),
            '5xx': result.get('status_5xx', 0),
            '请求成功率': result.get('success_rate', 0.0),
            'Windows': result.get('windows_count', 0),
            'Android': result.get('android_count', 0),
            'iOS': result.get('ios_count', 0),
            'MAC': result.get('mac_count', 0),
            '其它': result.get('other_count', 0),
        }

        # 添加IP TOP10字段
        for i in range(1, 11):
            chinese_num = ['', '第一', '第二', '第三', '第四', '第五', '第六', '第七', '第八', '第九', '第十'][i]
            db_data[f'IP{chinese_num}'] = result.get(f'ip_top{i}', '')

        # 添加path TOP10字段
        for i in range(1, 11):
            chinese_num = ['', '第一', '第二', '第三', '第四', '第五', '第六', '第七', '第八', '第九', '第十'][i]
            db_data[f'path{chinese_num}'] = result.get(f'path_top{i}', '')

        # 添加慢path TOP10字段
        for i in range(1, 11):
            chinese_num = ['', '第一', '第二', '第三', '第四', '第五', '第六', '第七', '第八', '第九', '第十'][i]
            db_data[f'慢path{chinese_num}'] = result.get(f'slow_path_top{i}', '')

        # 添加IP-path TOP10字段
        for i in range(1, 11):
            chinese_num = ['', '第一', '第二', '第三', '第四', '第五', '第六', '第七', '第八', '第九', '第十'][i]
            db_data[f'IP-path{chinese_num}'] = result.get(f'ip_path_top{i}', '')

        # 添加4xx错误path TOP10字段
        for i in range(1, 11):
            chinese_num = ['', '第一', '第二', '第三', '第四', '第五', '第六', '第七', '第八', '第九', '第十'][i]
            db_data[f'4xx{chinese_num}'] = result.get(f'error_4xx_top{i}', '')

        # 添加5xx错误path TOP10字段
        for i in range(1, 11):
            chinese_num = ['', '第一', '第二', '第三', '第四', '第五', '第六', '第七', '第八', '第九', '第十'][i]
            db_data[f'5xx{chinese_num}'] = result.get(f'error_5xx_top{i}', '')

        return db_data


def check_archive_table_exists(host, port, database, table, user, password):
    """
    检查归档表是否存在且有数据
    """
    try:
        client = Client(host=host, port=port, database=database, user=user, password=password)
        archive_suffix = os.getenv('ARCHIVE_TABLE_SUFFIX', '_archive_daily')
        archive_table = f"{table}{archive_suffix}"

        # 先检查表是否存在
        query = f"EXISTS TABLE {archive_table}"
        result = client.execute(query)
        table_exists = bool(result[0][0]) if result else False

        if not table_exists:
            return False

        # 表存在，再检查是否有数据
        count_query = f"SELECT count() FROM {archive_table}"
        count_result = client.execute(count_query)
        has_data = count_result[0][0] > 0 if count_result else False

        return has_data
    except Exception as e:
        logger.warning(f"检查归档表存在性失败: {e}")
        return False
    finally:
        if 'client' in locals():
            client.disconnect()


def main():
    parser = argparse.ArgumentParser(description='Nginx日志归档分析脚本')

    # 分析模式参数
    mode_group = parser.add_mutually_exclusive_group(required=False)
    mode_group.add_argument('--today', action='store_true', help='统计当天数据')
    mode_group.add_argument('--recent', type=int, metavar='DAYS', help='统计最近X天数据（不包括当天）')
    mode_group.add_argument('--all', action='store_true', help='统计全部数据（不包括当天）')

    args = parser.parse_args()

    try:
        # 从环境变量读取数据库配置
        db_config = {
            'host': os.getenv('CLICKHOUSE_HOST'),
            'port': int(os.getenv('CLICKHOUSE_PORT')),
            'database': os.getenv('CLICKHOUSE_DATABASE'),
            'table': os.getenv('CLICKHOUSE_TABLE'),
            'user': os.getenv('CLICKHOUSE_USER'),
            'password': os.getenv('CLICKHOUSE_PASSWORD', ''),
        }

        # 确定分析模式
        if args.today:
            mode = 'today'
            days = 0
            logger.info("开始分析当天数据...")
        elif args.recent:
            mode = 'recent'
            days = args.recent
            logger.info(f"开始分析最近{days}天数据（不包括当天）...")
        elif args.all:
            mode = 'all'
            days = 0
            logger.info("开始分析全部数据（不包括当天）...")
        else:
            # 默认运行方式：检查表是否存在
            table_exists = check_archive_table_exists(**db_config)

            if table_exists:
                # 表存在，执行 --recent 1
                mode = 'recent'
                days = 1
                logger.info("默认模式：归档表已存在，开始分析最近1天数据（不包括当天）...")
            else:
                # 表不存在，执行 --all
                mode = 'all'
                days = 0
                logger.info("默认模式：归档表不存在，开始分析全部数据（不包括当天）...")

        # 创建分析器实例
        analyzer = NginxLogAnalyzer(**db_config)

        # 执行分析
        results = analyzer.analyze(mode, days)

        # 输出结果
        analyzer.output_results(results)

    except Exception as e:
        logger.error(f"分析过程中出现错误: {e}")
        sys.exit(1)


def get_access_tables(host, port, database, user, password):
    """
    获取nginxlogs库中所有源表后缀结尾的表
    """
    try:
        source_suffix = os.getenv('SOURCE_TABLE_SUFFIX', '_access')
        client = Client(host=host, port=port, database=database, user=user, password=password)
        query = f"SHOW TABLES LIKE '%{source_suffix}'"
        result = client.execute(query)
        tables = [row[0] for row in result]
        return tables
    except Exception as e:
        logger.error(f"获取表列表时出现错误: {e}")
        return []


def main_with_table_check():
    """
    检查CLICKHOUSE_TABLE变量，如果为空则遍历所有_access表
    """
    clickhouse_table = os.getenv('CLICKHOUSE_TABLE')

    if not clickhouse_table or clickhouse_table.strip() == '':
        logger.info("CLICKHOUSE_TABLE变量为空，开始获取所有_access结尾的表...")

        # 获取数据库连接信息
        host = os.getenv('CLICKHOUSE_HOST')
        port = int(os.getenv('CLICKHOUSE_PORT'))
        database = os.getenv('CLICKHOUSE_DATABASE')
        user = os.getenv('CLICKHOUSE_USER')
        password = os.getenv('CLICKHOUSE_PASSWORD', '')

        # 获取所有_access结尾的表
        access_tables = get_access_tables(host, port, database, user, password)

        if not access_tables:
            logger.warning("未找到任何_access结尾的表")
            return

        logger.info(f"找到{len(access_tables)}个_access表: {', '.join(access_tables)}")

        # 依次处理每个表
        for table in access_tables:
            logger.info(f"开始处理表: {table}")
            # 临时设置环境变量
            os.environ['CLICKHOUSE_TABLE'] = table
            try:
                main()
                logger.info(f"表 {table} 处理完成")
            except Exception as e:
                logger.error(f"处理表 {table} 时出现错误: {e}")
                continue
    else:
        # CLICKHOUSE_TABLE有值，直接执行main()
        main()


if __name__ == '__main__':
    main_with_table_check()
