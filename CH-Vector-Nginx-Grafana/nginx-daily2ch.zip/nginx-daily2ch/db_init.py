#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClickHouse数据库初始化模块
用于创建归档表和删除过期数据
"""

import os
from clickhouse_driver import Client
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


def create_archive_table(host, port, database, table, user, password):
    """
    创建归档表结构

    Args:
        host: ClickHouse主机地址
        port: ClickHouse端口
        database: 数据库名
        table: 原表名
        user: 用户名
        password: 密码

    Returns:
        str: 归档表名
    """
    try:
        # 连接ClickHouse
        client = Client(host=host, port=port, database=database, user=user, password=password)

        # 生成归档表名
        archive_suffix = os.getenv('ARCHIVE_TABLE_SUFFIX', '_archive_daily')
        archive_table = f"{table}{archive_suffix}"

        # 创建表的SQL语句
        create_table_sql = f"""
        CREATE TABLE IF NOT EXISTS {archive_table}
        (
            `日期` Date,
            `域名` String,
            `高峰时段` String COMMENT '每0.5小时周期，取PV最大的周期',
            `最大QPS` UInt32 COMMENT '高峰期的最大QPS',
            `P99QPS` UInt32 COMMENT '高峰期的P99QPS',
            `平均RT` UInt32 COMMENT '高峰期的平均响应时间(ms)',
            `P99RT` UInt32 COMMENT '高峰期的P99响应时间(ms)',
            `P90RT` UInt32 COMMENT '高峰期的P90响应时间(ms)',
            `100ms以下` Float32 COMMENT '高峰期的<100ms请求数',
            `100-500ms` Float32 COMMENT '高峰期的100-500ms请求数',
            `500-1kms` Float32 COMMENT '高峰期的500ms-1s请求数',
            `1k-2kms` Float32 COMMENT '高峰期的1s-2s请求数',
            `2kms以上` Float32 COMMENT '高峰期的>2s请求数',
            `最大请求量` UInt64 COMMENT '高峰期的最大请求带宽(bps)',
            `最大返回量` UInt64 COMMENT '高峰期的最大响应带宽(bps)',
            `总UV` UInt64,
            `总PV` UInt64,
            `1xx` UInt32 COMMENT '1xx状态码数量',
            `2xx` UInt32 COMMENT '2xx状态码数量',
            `3xx` UInt32 COMMENT '3xx状态码数量',
            `4xx` UInt32 COMMENT '4xx状态码数量',
            `5xx` UInt32 COMMENT '5xx状态码数量',
            `请求成功率` Float32 COMMENT '请求成功率(%)(<400)',
            `Windows` Float32 COMMENT 'Windows系统请求数',
            `Android` Float32 COMMENT 'Android系统请求数',
            `iOS` Float32 COMMENT 'iOS系统请求数',
            `MAC` Float32 COMMENT 'MAC系统请求数',
            `其它` Float32 COMMENT '其它系统请求数',
            
            -- IP请求数TOP10
            `IP第一` String COMMENT '格式: 请求数:IP',
            `IP第二` String,
            `IP第三` String,
            `IP第四` String,
            `IP第五` String,
            `IP第六` String,
            `IP第七` String,
            `IP第八` String,
            `IP第九` String,
            `IP第十` String,
            
            -- path请求数TOP10
            `path第一` String COMMENT '格式: 请求数:路径',
            `path第二` String,
            `path第三` String,
            `path第四` String,
            `path第五` String,
            `path第六` String,
            `path第七` String,
            `path第八` String,
            `path第九` String,
            `path第十` String,
            
            -- 慢path TOP10
            `慢path第一` String COMMENT '格式: 响应时间ms:路径:请求数',
            `慢path第二` String,
            `慢path第三` String,
            `慢path第四` String,
            `慢path第五` String,
            `慢path第六` String,
            `慢path第七` String,
            `慢path第八` String,
            `慢path第九` String,
            `慢path第十` String,
            
            -- IP-path TOP10
            `IP-path第一` String COMMENT '格式: 请求数:路径:IP',
            `IP-path第二` String,
            `IP-path第三` String,
            `IP-path第四` String,
            `IP-path第五` String,
            `IP-path第六` String,
            `IP-path第七` String,
            `IP-path第八` String,
            `IP-path第九` String,
            `IP-path第十` String,
            
            -- 4xx错误path TOP10
            `4xx第一` String COMMENT '格式: 请求数:路径',
            `4xx第二` String,
            `4xx第三` String,
            `4xx第四` String,
            `4xx第五` String,
            `4xx第六` String,
            `4xx第七` String,
            `4xx第八` String,
            `4xx第九` String,
            `4xx第十` String,
            
            -- 5xx错误path TOP10
            `5xx第一` String COMMENT '格式: 请求数:路径',
            `5xx第二` String,
            `5xx第三` String,
            `5xx第四` String,
            `5xx第五` String,
            `5xx第六` String,
            `5xx第七` String,
            `5xx第八` String,
            `5xx第九` String,
            `5xx第十` String
        )
        ENGINE = MergeTree()
        PARTITION BY toYYYYMM(`日期`)
        ORDER BY (`日期`, `域名`)
        SETTINGS index_granularity = 8192;
        """

        # 执行创建表语句
        client.execute(create_table_sql)
        logger.info(f"Nginx日归档表 {archive_table} 初始化完成")

        return archive_table

    except Exception as e:
        logger.error(f"创建归档表失败: {e}")
        raise
    finally:
        if 'client' in locals():
            client.disconnect()


def delete_daily_data(host, port, database, archive_table, user, password, date):
    """
    删除指定日期的归档数据

    Args:
        host: ClickHouse主机地址
        port: ClickHouse端口
        database: 数据库名
        archive_table: 归档表名
        user: 用户名
        password: 密码
        date: 要删除的日期 (格式: YYYY-MM-DD)
    """
    try:
        # 连接ClickHouse
        client = Client(host=host, port=port, database=database, user=user, password=password)

        # 删除指定日期的数据
        delete_sql = f"ALTER TABLE {archive_table} DELETE WHERE `日期` = '{date}'"
        client.execute(delete_sql)
        logger.info(f"已删除日期 {date} 的所有数据")

    except Exception as e:
        logger.error(f"删除日期 {date} 的数据失败: {e}")
        raise
    finally:
        if 'client' in locals():
            client.disconnect()


def insert_daily_data(host, port, database, archive_table, user, password, data):
    """
    插入每日归档数据

    Args:
        host: ClickHouse主机地址
        port: ClickHouse端口
        database: 数据库名
        archive_table: 归档表名
        user: 用户名
        password: 密码
        data: 要插入的数据字典
    """
    try:
        # 连接ClickHouse
        client = Client(host=host, port=port, database=database, user=user, password=password)

        # 构建插入数据
        insert_data = [
            data['日期'],
            data['域名'],
            data['高峰时段'],
            data['最大QPS'],
            data['P99QPS'],
            data['平均RT'],
            data['P99RT'],
            data['P90RT'],
            data['100ms以下'],
            data['100-500ms'],
            data['500-1kms'],
            data['1k-2kms'],
            data['2kms以上'],
            data['最大请求量'],
            data['最大返回量'],
            data['总UV'],
            data['总PV'],
            data['1xx'],
            data['2xx'],
            data['3xx'],
            data['4xx'],
            data['5xx'],
            data['请求成功率'],
            data['Windows'],
            data['Android'],
            data['iOS'],
            data['MAC'],
            data['其它'],
            data['IP第一'],
            data['IP第二'],
            data['IP第三'],
            data['IP第四'],
            data['IP第五'],
            data['IP第六'],
            data['IP第七'],
            data['IP第八'],
            data['IP第九'],
            data['IP第十'],
            data['path第一'],
            data['path第二'],
            data['path第三'],
            data['path第四'],
            data['path第五'],
            data['path第六'],
            data['path第七'],
            data['path第八'],
            data['path第九'],
            data['path第十'],
            data['慢path第一'],
            data['慢path第二'],
            data['慢path第三'],
            data['慢path第四'],
            data['慢path第五'],
            data['慢path第六'],
            data['慢path第七'],
            data['慢path第八'],
            data['慢path第九'],
            data['慢path第十'],
            data['IP-path第一'],
            data['IP-path第二'],
            data['IP-path第三'],
            data['IP-path第四'],
            data['IP-path第五'],
            data['IP-path第六'],
            data['IP-path第七'],
            data['IP-path第八'],
            data['IP-path第九'],
            data['IP-path第十'],
            data['4xx第一'],
            data['4xx第二'],
            data['4xx第三'],
            data['4xx第四'],
            data['4xx第五'],
            data['4xx第六'],
            data['4xx第七'],
            data['4xx第八'],
            data['4xx第九'],
            data['4xx第十'],
            data['5xx第一'],
            data['5xx第二'],
            data['5xx第三'],
            data['5xx第四'],
            data['5xx第五'],
            data['5xx第六'],
            data['5xx第七'],
            data['5xx第八'],
            data['5xx第九'],
            data['5xx第十'],
        ]

        # 插入数据
        client.execute(f"INSERT INTO {archive_table} VALUES", [insert_data])
        logger.info(f"数据插入成功: {data['日期']} - {data['域名']}")

    except Exception as e:
        logger.error(f"插入数据失败: {e}")
        raise
    finally:
        if 'client' in locals():
            client.disconnect()
